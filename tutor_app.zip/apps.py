from django.apps import AppConfig


class TutorAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "tutor_app"
